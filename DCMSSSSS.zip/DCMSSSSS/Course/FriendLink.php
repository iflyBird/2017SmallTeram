<html>
<style>
body{
	padding:0;
	margin:0;
	
}
#wrap{
	width:100%;
	height:100%;
}
	#title {
			background:#8DB6CD;
			width: 100%;
			height: 60px;
			}
			#title img {
			margin-left: 550px;
			}
			#title-left {
			float: left;
			}
#title-right {
		   width:320px;
			float: right;
			font-size: 24px;
			font-weight:bold;
			font-family:"华文行楷";
			margin-right: 460px;
			margin-top:4px;
			}
			#title-right marquee{
				margin-top:0px;

			}
			
			#left{
			font-size:large;
			background:	#BCD2EE;
			margin-top:0px;
		    margin-left:0px;
			float:left;
            width:10%;
			height:800px;			
			}
			#right{
				background:#D1EEEE;
				margin-left:0px;
			margin-top:0px;
            width:90%;
			float:right;
			}

			ul li{
				line-height:50px;
			
            	list-style:none;
			}
			ul li a{
	font-size:16px;
			}
			.yqcontent{
				height:800px;
				width:1200px;
				
				float:left;
				margin-top:0px;
			}
			.yqcontent-top{
				height:300px;
				width:1200px;
				background:url("img/yqbj1.jpg") no-repeat;
	            background-size:90%;
				float:left;
				margin-top:10px;
			}
			.yqcontent-b{
				height:120px;
				width:1200px;
				
				float:left;
				margin-top:10px;
				
			}
			.yqcontent-b table{
				width:120px;
				height:100px;
				border-spacing:50px 50px;
			}
			
             #youqing-b-z{
				color:white;
			    width:500px;
				height:120px;
             	float:left;
             	margin-left:650px;
             	
             		margin-top:320px;
             	position:absolute;
                 font-family:"宋体";
             	color:orange;
			}
			
             #youqing-b-z1{
				color:white;
			    width:500px;
				height:120px;
             	float:left;
             	margin-left:500px;
             
			}
			
			.yqcontent-b img{
				width:30px;
				height:30px;
			}
			
			.yqcontent-b2{
				height:250px;
				width:1200px;
				background-color:gray;
				float:left;
				margin-top:480px;
            	position:absolute;
			}
			
            .yqcontent-b3{
				height:205px;
				width:1160px;
				background-color:#1E212D;
				float:left;
				margin-top:500px;
            	margin-left:20px;
            	position:absolute;
			}
			.yqcontent-b4{
				height:200px;
				width:1200px;
				float:left;
				margin-top:10px;
			}
			.youqingb-l{
				height:180px;
				width:320px;
				
				margin-left:100px;
				float:left;
				margin-top:30px;
				
			}
			
			.youqingb-l-t{
				height:90px;
				width:320px;
				background:url("img/beijing2.png") no-repeat;
				 background-size:110%;
				float:left;
				margin-top:0px;
			}
           .youqingb-l-b{
				height:90px;
				width:320px;
       
               font-family:"宋体";
				float:left;
			}
			.youqingb-r{
				height:180px;
				width:600px;
				
				margin-right:100px;
				float:right;
				margin-top:30px;
			}
			.youqingb-r  a{
				color:white;
				 text-decoration:none;
			}
			p{
				color:white;
			}
			.youqingb-r table{
				color:white;
			    width:500px;
				height:30px;
				margin-left:100px;
				margin-top:30px;
				font-family:sans-serif;
				
			}
	a:link{
	         color:black;
			}
			a:visited{
	        color:blue;
			}
			a:hover{
				font-size:150%;
	        color:red;
			}
			

</style>
<head>
</head>
<body>
<div id="wrap">
			<div id="title">
				<div id=title-left>
					<img src="img/school.png" />
					
				</div>
				<div id=title-right>
					<marquee>安徽信息工程学院学科竞赛管理系统</marquee>
				</div>
				</div>
				<div id="left">
				<h3>导航菜单</h3>
				
				<ul>
				        <li><a href="HomePage.php"	style="border-right:1px solid color;">网站首页</a></li>			       
						<li><a href="NewsCenter.php">新闻中心</a></li>
						<li><a href="Announce.php">通知公告</a></li>
						<li><a href="Mannger.php">管理规定</a></li>
						<li><a href="ContestsProject.php">竞赛项目</a></li>
						<li><a href="CompetitionResult.php">竞赛成果</a></li>
						<li><a href="newfile.php">文件下载</a></li>
						<li><a href="ContactUs.php">联系我们</a></li>
						<li><a href="FriendLink.php">友情链接</a></li>
						<li><a href="UsingHelp.php">使用帮助</a></li>
					     <li><a href="Login.php">用户登陆</a></li>	
				</ul>	
				</div>
				<div id="right">
				<div class="yqcontent">
				<div class="yqcontent-top">
				</div>
				<div class="yqcontent-b">
				<table >
				<tr>
				<td>
				 <a href="https://www.baidu.com/"><img src="img/baidu.png"></a>
				</td>
				<td>
				 <a href="http://www.sohu.com/"><img src="img/souhu.png"></a>
				</td>
				<td>
				 <a href="http://www.iqiyi.com/"><img src="img/aiqiyi.png"></a>
				</td>
				<td>
				 <a href="http://www.qq.com/"><img src="img/QQ.png"></a>
				</td>
				<td>
				 <a href="http://weibo.com/"><img src="img/weibo.jpg"></a>
				</td>
				<td>
				 <a href="https://www.taobao.com/"><img src="img/taobao.png"></a>
				</td>
				</tr>
				</table>
				
				</div>
				<div id="youqing-b-z">
				<h1>Welcome To Use The LINK </h1>
				<h2>To Get Learning Resources</h2>>
				</div>
				<div class="yqcontent-b2">
				
				</div>
				<div class="yqcontent-b3">
				<div class="youqingb-l">
				<div class="youqingb-l-t">
				</div>
				<div class="youqingb-l-b">
				<p>版权所有 安徽信息工程学院|小学期A1丛林班</p>
				<p>技术支持：勇于争先组</p>
				</div>
				</div>
				<div class="youqingb-r">
				<table>
				<tr>
				<td><strong>校内网站链接</strong></td>
				<td><strong>教育类网站链接</strong></td>
				</tr>
				<tr>
				<td><a href="http://jw.ahpumec.edu.cn:10000/jwweb/">教务处管理系统</a></td>
				<td><a href="http://www.moe.edu.cn/">教育部网站</a></td>
				</tr>
				<tr>
				<td><a href="http://www.ahpumec.edu.cn/3dmap2/">学院三维全景地图</a></td>
				<td><a href="http://www.ahedu.gov.cn/">安徽省教育厅</a></td>
				</tr>
				<tr>
				<td><a href="http://www.ahpumec.edu.cn/index.php?s=admin&c=login">网站后台管理</a></td>
				<td></td>
				</tr>
				
				</table>
				</div>
				</div>
				</div>
			</div>
			</div>

</body>
</html>
