<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>参赛队伍统计</title>
<style type="text/css">
 body {
             background-color:#B6C4F5;
 	background-image:url(img/pb19.jpg);
 	background-repeat: no-repeat;
 	background-size: cover;
            }
</style>
</head>
<?php 
      
    
    $conn=mysql_connect("localhost","root","");
    mysql_select_db("dcms");
    mysql_query("set names utf8");
   
     $sql="select  COUNT(distinct stuID) from studentinfor,team,enlistresult
        where studentinfor.stuID=team.captainID
        AND team.teamID=enlistresult.teamID ";//[根据$sql语句的limit 后面的两个值（起始值，每页条数），来实现分页。以及求得这两个值。
     $res2=mysql_query($sql,$conn) or die('无法获取结果集'.mysql_error());
     //echo '<table border=1>';  
     echo "<caption><font size='8' color='blue'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;参赛人数统计</font></caption>";
     echo"<form action='teamSelectAction1.php' method='post'>";
     echo "<table border='1' cellspacing='0' width='400' align='center'>";
     echo"<br/>";
     echo"<hr/>";
     $res1=mysql_query($sql);
     //4.11取出行数
     if(($row=mysql_fetch_row($res2))!=false){
         $rowCount=$row[0];
     }
     echo"<tr>";
     echo "<td align='center'>参赛人数</td>";
     echo "<td align='center'>".$rowCount."</td>";
     echo "</tr>";
   
     echo "</table>";
     mysql_free_result($res2);
     mysql_close($conn);
     echo"<hr/>";
   
     echo"<a href='TeacherPage.php' ><b><font size='5' color='red'>返回</font></b></a>";
?>
</html> 