
<?php 
session_start();
@$username=$_SESSION["username"];
@$IdCard=$_SESSION["IdCard"];

if(!isset($username)){
   header("location:HomePage.php");
}if($IdCard!="教师"){
   header("location:Homepage.php");
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>学科竞赛管理系统</title>
	       <link rel="stylesheet" href="css/TeacherPage.css" >   
	       
	       <script type="text/javascript" src="js/TeacherPage.js">

	    		       
          </script> 
	</head>
	
	<body style="margin: 0; background-image:url(img/teacher.pic.jpg)">
		<div id="main">
		
			<div id="top">
				<div id="top_left">
        				<div id="iron" style="background-image:url(img/school.png);" >
        				
        				</div>
        				
        				<div id="title">
				                <div id="title_top">学科竞赛管理系统
				
				                </div>
				                <div id="title_buttom">Discipline competition management system
				
				                 </div>
				       </div>
        				
				</div>
				
				<div id="top_right">
				
				        <div id="top_right_right">
				        
				
				                <div id="top_right_right_top"># 帮助  |关于 <a href="Login.php">退出</a>
				               <a href="HomePage.php"style="text-decoration: none;">首页</a>
				                </div>
				
				                <div id="top_right_right_buttom"><input type="text" value="You Believe Us">
				                </div>
				
				
				        </div>
				
				        <div id="top_right_left">
				
				
				        </div>
				        
				
				
				</div>
				
				
			</div>
			
			<div id="buttom">
				<div id="inner_left">
				    <div id="inner_left_top">功能菜单
				    </div>
				     <div id="inner_left_buttom">
				        
				        <div class="inner" onclick="change_1();">赛事信息
				        </div>
				        <div class="inner_1"onclick="window.location.href='Announce.php'">软件杯
				       </div>
				       <div class="inner_1"onclick="window.location.href='Announce.php'">大学生程序设计大赛
				       </div>
				       <div class="inner_1"onclick="window.location.href='Announce.php'">挑战杯
				       </div>
				       <div class="inner_1"onclick="window.location.href='Announce.php'">ACM程序设计大赛
				       </div>
				       <div class="inner_1"onclick="window.location.href='Announce.php'">专利设计大赛
				       </div>
				        <div class="inner" onclick="change_2();">基本信息
				       </div>
				        <div  class="inner_2" onclick="window.location.href='TstuList1.php'">学生信息
				        </div>
				       <div  class="inner_2" onclick="window.location.href='TteaList2.php'">老师信息
				       </div>
				        <div  class="inner_2" onclick="window.location.href='TmanList.php'">管理员信息
				       </div>
				       <div class="inner" onclick="change_3();">竞赛信息
				       </div>
				       <div  class="inner_3" onclick="window.location.href='TcomList2.php'">赛事信息</div>
				       <div  class="inner_3" onclick="window.location.href='TapplyList1.php'">报名信息</div>
				       <div  class="inner_3" onclick="window.location.href='TteamList1.php'">团队信息</div>
				       <div  class="inner_3" onclick="window.location.href='TconList1.php'">报名结果</div>
				       <div class="inner" onclick="change_4();">报名情况统计
				       </div>
				       <div class="inner_4" onclick="window.location.href='Tclass.php'">按学生班级统计
				       </div>
				       <div class="inner_4" onclick="window.location.href='Tsex.php'">按学生性别统计
				       </div>
				       <div class="inner_4" onclick="window.location.href='Tgrade.php'">按学生年级统计
				       </div>
				        <div class="inner_4" onclick="window.location.href='Tpro.php'">按系部统计
				       </div>
				        <div class="inner_4" onclick="window.location.href='Tcount.php'">统计所有人数
				       </div>
				       <div class="inner" onclick="change_5();" >
				       </div>
				       <div class="inner_5"  onmouseover="chanage_color(this);">1
				       </div>
				       <div class="inner_5">1
				       </div>
				       <div class="inner_5">1
				       </div>
				    </div>
				</div>
				<div id="inner_right">
					<div id="inner_right_top">
					<br/>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;当前位置：教师界面
					</div>
					
						
		       </div>
		    </div>
		</div>
	</body>
</html>
