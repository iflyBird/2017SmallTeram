<?php 
include "MySqlAdmin.php";

@$content=$_GET["content"];
$sql="insert into feedback values('','$content')";
 mysql_query($sql);
 //print_r($sql);
  //echo "1";
  mysql_close();
  
  echo "<a href='UserFeedback.php'>返回上一级</a>";






?>