<html>
<style type="text/css">
            body{
	             padding:0;
	            margin:0;
	
            }
			
	        #title:hover {
		
		        font-size:150%;
		       background:#87CEFA;
	         }							


	        #title {
			background:#8DB6CD;
			width: 100%;
			height: 60px;
	        margin-bottom:0px;
	  
	        	
			}
			#title img {
			margin-left: 550px;
			}
			#title-left {
			float: left;
			}
			#title-right {
		   width:320px;
			float: right;
			font-size: 24px;
			font-weight:bold;
			font-family:"华文行楷";
			margin-right: 460px;
			margin-top:4px;
			}
			#title-right marquee{
				margin-top:0px;

			}
			
			#left{
			
			margin-top:0px;
		    margin-left:0px;
			float:left;
            width:10%;
			height:1000px;
		    background:#BCD2EE;	
				
			}
			#right{
	        margin-top:0px;
		    float:right;
			width:90%;
		    height:1000px;
			padding-top:0px;
			padding-left:0px;
	       	background:#D1EEEE;
		
			}
			#right-top{
			margin-top:0px;
			margin-left:0px;
            width:100%;
			height:70px;
			background: #D1EEEE;
			border:1px white solid;
			
			}
			#right-bottom{
	        margin-top:0px;
			width:99%;
		
			}

			ul li{
				line-height:50px;
            	list-style:none;
			}
			a{
	         text-decoration: none;
			 color:blue;
			 font-style: oblique;
			 font-size: large;	
			}
			a:link{
	         color:black;
			}
			a:visited{
	        color:blue;
			}
			a:hover{
				font-size:150%;
	        color:red;
			}

</style>
<head>
</head>
<body>

			<div id="title">
				<div id=title-left>

					<a href="http://www.ahpumec.edu.cn/"><img src="img/school.png" /></a>
				</div>
				<div id=title-right>
					<marquee>安徽信息工程学院学科竞赛管理系</marquee>

				</div>
			</div>

				<div id="left" align="center">
				<h2 style="font-family: arial">导航菜单</h2>
				
				<ul>
				        <li><a href="HomePage.php"target="parent" style="border-right:1px solid color;">网站首页</a></li>			       
						<li><a href="NewsCenter.php">新闻中心</a></li>
						<li><a href="Announce.php">通知公告</a></li>
						<li><a href="Mannger.php">管理规定</a></li>
						<li><a href="ContestsProject.php">竞赛项目</a></li>
						<li><a href="CompetitionResult.php">竞赛成果</a></li>
						<li><a href="newfile.php">文件下载</a></li>
						<li><a href="ContactUs.php">联系我们</a></li>
						<li><a href="FriendLink.php">友情链接</a></li>
						<li><a href="UsingHelp.php">使用帮助</a></li>
					    <li><a href="Login.php">用户登陆</a></li>	
				</ul>	
				</div>
				<div id="right">
				   <div id="right-top">
				      <h3>学科竞赛系统使用帮助</h3>
				      
				   </div>
				   <div id="right-bottom">
			          <p style="text-align: center;">
    <span style="font-family: 微软雅黑,Microsoft YaHei; font-size: 24px; text-decoration: none;"><strong>使用帮助</strong></span>
</p>
<p style="text-align: left; text-indent: 2em;">
    <strong><span style="color: rgb(0, 112, 192); font-family: 微软雅黑,Microsoft YaHei; font-size: 20px; text-decoration: none;">随着教育信息化的普及，学校认识到对学生的管理需要借助互联网。传统的方法管理学生有许多的不方便，而我们的学科竞赛报名系统就是教学结合互联网的一种体现，学生可以通过我们的系统进行网上在线报名，而不用像传统方式一级级往上申报。教师可以通过本系统对竞赛的各个情况进行一个直观的了解，如每个竞赛的参赛人员有多少，参赛人员的分布情况，我们都能够通过图表的形式展现出来，教师用户使用DCMS8系统可以对各个情况一目了然。管理员用户可以通过本系统发布一些竞赛公告和上传一些文件提供给其他用户下载，如报名表、竞赛文件等。</span></strong>
</p>
<p style="text-align: left; text-indent: 2em;">
    <strong><span style="color: rgb(0, 112, 192); font-family: 微软雅黑,Microsoft YaHei; font-size: 20px; text-decoration: none;">本项目采用B/S结构，方便参赛人员、教师、管理人员使用。参赛人员可以通过该系统报名参赛，管理人员可以通过系统了解各个竞赛的参赛人员以及各个竞赛的参赛情况，同时还可以查看学科竞赛的各种分布情况。</span></strong>
</p>
<p style="text-align: left; text-indent: 2em;">
    <strong><span style="color: rgb(0, 112, 192); font-family: 微软雅黑,Microsoft YaHei; font-size: 20px; text-decoration: none;"><br/></span></strong>
</p>
<p style="text-indent: 2em;">
    <span style="color: rgb(255, 0, 0); font-size: 24px;"><strong><span style="color: rgb(255, 0, 0);">功能1：竞赛设置、准考证打印和成绩登录、公布</span></strong></span>
</p>
<p style="text-indent: 2em;">
    <span style="font-family: 隶书, SimLi; font-size: 24px;">（1）使用者：学院竞赛组织管理者、学校竞赛组织管理者、竞赛指导教师、参赛学生。</span>
</p>
<p style="text-indent: 2em;">
    <span style="font-family: 隶书, SimLi; font-size: 24px;">（2）目的：简化竞赛组织准备工作流程，方便师生查阅信息，使组织管理工作更加便捷。</span>
</p>
<p style="text-indent: 2em;">
    <span style="font-family: 隶书, SimLi; font-size: 20px;">（3）功能（业务）内容描述竞赛组织管理者设置竞赛名称、时间、参赛对象；根据学生报名情况分配考场，打印准考证；学生在报名允许时间段内登录系统，点击报名参赛，考试前可查阅考场信息，考试后可查询竞赛成绩；竞赛指导教师可登录系统录入成绩；各学院教务秘书（或学生）可自行打印准考证。</span>
</p>
<p style="text-align: left; text-indent: 2em;">
    <span style="font-family: 微软雅黑,Microsoft YaHei; font-size: 20px; text-decoration: none;"></span>
</p>
<p style="text-indent: 2em;">
    <strong><span style="color: rgb(255, 0, 0); font-size: 24px;">功能2：竞赛学生获奖和教师指导竞赛情况录入和查询</span></strong>
</p>
<p style="text-indent: 2em;">
    <span style="font-family: 隶书, SimLi; font-size: 24px;">（1）使用者：学院竞赛组织管理者、学校竞赛组织管理者、竞赛指导教师。 </span>
</p>
<p style="text-indent: 2em;">
    <span style="font-family: 隶书, SimLi; font-size: 24px;">（2）目的：简化竞赛获奖情况认定流程，方便师生查阅信息。</span>
</p>
<p style="text-indent: 2em;">
    <span style="font-family: 隶书, SimLi; font-size: 24px;">（3）功能（业务）内容描述每个竞赛承办学院都有录入相应赛事的报名、培训、参赛和获奖情况的权限，录入信息包括：赛事信息、教师指导信息、获奖信息。</span>
</p>
<p style="text-align: left; text-indent: 2em;">
    <span style="font-family: 微软雅黑,Microsoft YaHei; font-size: 20px; text-decoration: none;">&nbsp; <img src="http://img.baidu.com/hi/jx2/j_0019.gif"/><img src="http://img.baidu.com/hi/jx2/j_0019.gif"/><img src="http://img.baidu.com/hi/jx2/j_0028.gif"/></span>
</p>
				   </div>
				</div>

</body>
</html>