<?php

session_start();
$pname=$_SESSION["username"];

echo "<div style='float :right ;width:100px;height:10px margin-top:-40px;margin-left:180px;'>";
echo "<span>";
echo "<a href=''>".$pname."|</a>"."<a href =''>注销</a>";
echo "</span>";
echo "</div>";

?>