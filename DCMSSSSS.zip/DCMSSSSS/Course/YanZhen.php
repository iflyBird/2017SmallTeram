<?php
#注册成功向数据库添加账户
include "MySqlAdmin.php";
#$_POST["compId"]=$_POST["compId"];



if($_POST["compId"]=="用户注册")
{
   // mysql_connect("localhost","root");
    //mysql_select_db("coursecontests");
    $name=$_POST["zhuce_admin"];
    $password=$_POST["zhuce_password"];
    $sql="INSERT INTO outpeo values('null','$name','$password','null')";
    $result=mysql_query($sql);
    #var_dump($result);
}


//-------------------------登录验证------------------------------------
	function CheckPassword($name,$password)
	
	{
	   
	     
		if("SELECT*FROM outpeo where outName='$name' and outPwd='$password'"){
		   
		   
			echo "登录成功<br>";
			echo "当期用户:".$name."<br>";		
			
		}else{
		    echo "登录失败,请重新登陆";
		}
		
		
		#else echo "登录失败，用户名或密码错误,请重新登陆或者注册.";
		}
		
//---------------------------注册直接进入----------------------------------		
	function into($name)
	{
	    session_start();
	    $_SESSION["username"]=$name;
	    $_SESSION["IdCard"]="非在校人员";
		echo "注册成功<br>";
		echo "当期用户:".$name."<br>"; 
		header("location:HomePage.php");
	}
	
//---------------------comdId为登录或者注册的识别标签----------------------------------------	
	if($_POST["compId"]=="用户注册")
	{
		into($_POST["zhuce_admin"]);
}
	
//-------------------------------------------------------------	
	else 
	    if($_POST["compId"]=="用户登录")
	{
		CheckPassword($_POST["admin"],$_POST["password"]);
	}
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
		
	
	
?>

<!-- 所有与数据库交互信息写在此页 -->