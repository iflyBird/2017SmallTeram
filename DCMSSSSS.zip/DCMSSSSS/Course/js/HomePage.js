<script>
		window.onload = function() {
			var content = document.getElementById("content");
			var oA = document.getElementsByClassName("a");
			var picArr = ['img/u1.jpg', 'img/u2.jpg', 'img/u3.jpg', 'img/u4.jpg', 'img/u5.jpg'];
			var index = 0;
			var timer;
			content.style.background = "url(" + picArr[index] + ")";
			timer = setInterval(function() {
				content.style.background = "url(" + picArr[index] + ")";
				index++;
				if (index == picArr.length) {
					index = 0;
				}
			}, 1000);
			for (var i = 0; i < oA.length; i++) {
				oA[i].index = i;
				oA[i].onclick = function() {
					index = this.index;
					content.style.background = "url(" + picArr[this.index] + ")";
					return false;
				}
			}
		}
	</script>