<!--------------------提交对输入信息是否完整和验证码是否正确进行检查-------------------->
	function read()
	{ 
		if (document.getElementById("Code").value=="")
		{
			alert("请输入验证码！");
			return false;
		}
	else if(document.getElementById("admin").value=="")
		{
			alert("请输入用户名！");
			return false
		}
	else if(document.getElementById("password").value=="")
		{
			alert("请输入密码！");
			return false;
		}
	else if(document.getElementById("Code").value != document.getElementById("cCode").value)
		{
			alert("验证码错误！");
			return false;
		}
		else
		{
			var se=confirm("确认登录吗？");
			if (se==true)
				return true;
			else
				return false;
		 }
	}
	