/**
 * 
 */
function change_1(){
	var tem=document.getElementsByClassName('inner_1');
	for(var i=0; i<tem.length;i++)
	{
		if(tem[i].style.display=="none"){
			tem[i].style.display="block";
		}
		else{
			tem[i].style.display="none";
	}
}
}
function change_2(){
	var tem=document.getElementsByClassName('inner_2');
	for(var i=0; i<tem.length;i++)
	{
		if(tem[i].style.display=="none"){
			tem[i].style.display="block";
		}
		else{
			tem[i].style.display="none";
	}
}
}

function change_3(){
	var tem=document.getElementsByClassName('inner_3');
	for(var i=0; i<tem.length;i++)
	{
		if(tem[i].style.display=="none"){
			tem[i].style.display="block";
		}
		else{
			tem[i].style.display="none";
	}
}
}


function change_4(){
	var tem=document.getElementsByClassName('inner_4');
	for(var i=0; i<tem.length;i++)
	{
		if(tem[i].style.display=="none"){
			tem[i].style.display="block";
		}
		else{
			tem[i].style.display="none";
	}
}
}


function change_5(){
	var tem=document.getElementsByClassName('inner_5');
	for(var i=0; i<tem.length;i++)
	{
		if(tem[i].style.display=="none"){
			tem[i].style.display="block";
		}
		else{
			tem[i].style.display="none";
	}
}
}
function change_6(){
	var tem=document.getElementsByClassName('inner_6');
	for(var i=0; i<tem.length;i++)
	{
		if(tem[i].style.display=="none"){
			tem[i].style.display="block";
		}
		else{
			tem[i].style.display="none";
	}
}
}















