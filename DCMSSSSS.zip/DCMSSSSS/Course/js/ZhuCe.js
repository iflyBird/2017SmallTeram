function run()
 		{
 	 		d=document.getElementById("day").value;
 	 		m=document.getElementById("month").value;
 	 		y=document.getElementById("years").value;
 			
 			if ((m==4||m==6||m==9||m==11)&&(d==31))
 			{
	 	 	 		alert("日期格式错误");
	 	 	 		return false;
	 	 	}
 			else if (((y%400==0)||((y%100!=0)&&y%4==0)) &&m==2 &&d>29)
 	 		{
 	 	 	 	 	alert("日期格式错误");
 	 	 	 	 	return false;
 	 	 	 }
 			else if(((y%4!=0)||((y%100==0)&&y%400!=0)) &&m==2 &&d>28)
 			{
	 	 	 		alert("日期格式错误");
	 	 	 		return false;
	 	 	}
 			else if(document.getElementById("admin").value=="")
 				{
 					alert("请输入用户名！");
 					return false;
 				}
 			else if(document.getElementById("password").value=="")
 				{
 					alert("请输入密码！");
 					return false;
 				}
 			else if(y=="请选择"||m=="请选择"||d=="请选择")
 	 			{
 					alert("请选择出生日期！");
					return false;
 	 			}
			else
			{
				var se=confirm("确认注册吗？");
				if (se==true)
					return true;
				else
					return false;
		 }		 
 	 	}
 	 	
<!--------------------判断日期-------------------->		
 	 	function check()
 	 	{
 	 	 	d=document.getElementById("day").value;
 	 		m=document.getElementById("month").value;
 	 		y=document.getElementById("years").value;
 	 		
 	 		if ((m==4||m==6||m==9||m==11)&&(d==31))
 	 	 	{
 	 	 	 	alert("温馨提示，这个月只有30天！");
 	 	 	}
 			else if (((y%400==0)||((y%100!=0)&&y%4==0)) &&m==2 &&d>29)
 	 		{
 	 	 	 	 alert("温馨提示，这个月只有29天！");
 	 	 	 }
 			else if(((y%4!=0)||((y%100==0)&&y%400!=0)) &&m==2 &&d>28)
 	 	 	 {
	 	 	 	 alert("温馨提示，这个月只有28天！");
 	 	 	 }
 	 		
 	 	}