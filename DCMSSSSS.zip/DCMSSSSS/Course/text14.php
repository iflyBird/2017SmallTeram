<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HTML5 Canvas五彩烟花动画特效 - 站长素材</title>

<style>
*{
	padding: 0;
	margin: 0;
}
</style>

</head>
<body>

<div id="example">

</div>
<div>

<input type="text" >
</div>















<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/firework.js"></script>
<script type="text/javascript">
	$(function(){
		$("#example").fireworks({
			width: "100%",
			height: "100%"
		});
	});
</script>

<div style="text-align:center;margin:50px 0; font:normal 14px/24px 'MicroSoft YaHei';">

</div>









</body>
</html>
