  <html>
  <head>
  <style>
  
*{margin: 0;padding: 0;}
html,body{height: 100%;background: white;}
.wrap{

	margin-left:-1200px;
	margin-top:120px;
	position: relative;
	-webkit-transform-style:preserve-3d;
	 -webkit-perspective:0px;

	  -moz-transform-style:preserve-3d;
	  -moz-perspective:0px;

	  -webkit-animation:mydhua 2s ease infinite;
	  -moz-animation:mydhua 2s ease infinite;

	 

}
.box{width: 200px;height: 200px;position: absolute;top: 50%;left: 50%;
	 margin:-100px 0 0 -100px; line-height: 200px;text-align: center;font-size: 48px;color: white;
		}
.box1{
	-webkit-transform:rotatey(90deg) translatez(-100px);
	-moz-transform:rotatey(90deg) translatez(-100px);
	background: rgba(128,0,128,.5);
}
.box2{
	-webkit-transform:rotatey(90deg) translatez(100px);
	-moz-transform:rotatey(90deg) translatez(100px);
	background: rgba(255,0,255,.5);
}
.box3{
	-webkit-transform:rotatex(90deg) translatez(100px);
	-moz-transform:rotatex(90deg) translatez(100px);
	background: rgba(255,153,204,.5);
}
.box4{
	-webkit-transform:rotatex(90deg) translatez(-100px);
	-moz-transform:rotatex(90deg) translatez(-100px);
	background: rgba(0,204,255,.5);
}
.box5{
	-webkit-transform: translatez(-100px);
	-moz-transform:translatez(-100px);
	background: rgba(153,204,255,.5);
}
.box6{
	-webkit-transform: translatez(100px);
	-moz-transform:translatez(100px);
	background: rgba(0,255,255,.5);
}

@-webkit-keyframes mydhua{

	0%{-webkit-transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);-webkit-transform-origin: center center;}
	100%{-webkit-transform:rotateX(180deg) rotateY(180deg) rotateZ(180deg);-webkit-transform-origin: center center; }
}
@-moz-keyframes mydhua{

	0%{-moz-transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);-webkit-transform-origin: center center;}
	100%{-moz-transform:rotateX(180deg) rotateY(180deg) rotateZ(180deg); -webkit-transform-origin: center center;}
}
  
  
  
  
  
  
  </style>
  
  
  
  </head>
  <body style="background-image: url(img/background.jpg)">
  
  
  <div class="wrap"style="margin-top:-5px;">
        <div class="box1 box">
            </div>
        <div class="box2 box">
            </div>
        <div class="box3 box">
            </div>
        <div class="box4 box">
            </div>
        <div class="box5 box">
            </div>
        <div class="box6 box">
            </div>
    </div>
    <div style="margin-top:200px;">sss</div>
  
  
  </body>
  
  
  </html>
  
  