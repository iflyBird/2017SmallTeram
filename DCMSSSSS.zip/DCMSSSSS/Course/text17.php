<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="UTF-8">
		<title>Title</title>
		<style>
			*{
			            padding:0;
			            margin:0;
			        }
			        #title{
			        	width:1600px;
			            background:black;
			            height:40px;
			           
			        }
			        #wrap{
			        	
			        	height:800px;
			        	width:1600px;
			        
			        	margin-top:0px;
			        }
			        ul li {
			            margin-left: 20px;
			
			            display: inline;
			            list-style: none;
			            float:left;
			
			        }
			        ul li a{
			        	text-align:center;
			        
			            font-size: 24px;
			
			            text-decoration:none;
			        }
			        #content-left{
			            float:left;
			        	border: 1px solid red;
			  
			        	width:300px;
			        	height:800px;
			        	
			        }
			     #content-right{
			         
			        	border: 1px solid red;
			
			        margin-left: 0px;
			        	height:800px;
			        }
			       #content-left-top{
			        	border: 1px solid red;
			        	width:300px;
			        	height:200px;
			        }
			         #content-left-bottom{
			         	border: 1px solid red;
			        	width:300px;
			        	height:600px;
			        }
			
		</style>
	</head>

	<body>
		<div id="title">
			<ul>
				<li><a href="#" style="margin-left:40px">个人中心</a> </li>
				<li><a href="#">我的资料</a> </li>
				<li><a href="#">学校官网</a> </li>
				<li><a href="#">注册</a> </li>
				<li><a href="#">登陆</a> </li>

			</ul>

		</div>
		<div id="wrap">
			<div id="content-left">
				<div id="content-left-top">s</div>
				<div id="content-left-bottom">s</div>

			</div>
			<div id="content-right">
				ssssssssssssssss
			</div>

		</div>

	</body>

</html>