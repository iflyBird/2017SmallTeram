<!DOCTYPE HTML>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <title>ueditor demo</title>

</head>


<body>
    <form action="ueditorAction.php" method="post">
    <div>
    <div>
    <h3>发布新闻</h3>
    <input type="text"  name="name" style="width: 800px">
    </div>
    <div>
    <h3>发布时间</h3>
    <input type="text" name="time" style="width: 800px">
    </div>
    <!-- 加载编辑器的容器 -->
    <script id="container" name="content" type="text/plain" style="width:100%;height:400px;">
        这里写你的初始化内容
    </script>
    <!-- 配置文件 -->
    <script type="text/javascript" src="ueditor/ueditor.config.js"></script>
    <!-- 编辑器源码文件 -->
    <script type="text/javascript" src="ueditor/ueditor.all.js"></script>
    <!-- 实例化编辑器 -->
    <script type="text/javascript">
        var ue = UE.getEditor('container');
    </script>
    
    <input type="submit"value="提交">
    </div>
    </form>
</body>

</html>