<?php 
    $edit = $_GET["myEdit"];
    echo $edit;


?>