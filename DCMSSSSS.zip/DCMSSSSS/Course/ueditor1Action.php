<?php
include 'MySqlAdmin.php';
mysql_query("SET NAMES 'utf8'");

  $name=$_POST["name"];
  $time=$_POST["time"];
  $content=$_POST["content"];
  
  $sql = "insert into news( newsName,newsTime,newsInfor) values('$name','$time','$content')";
  mysql_query($sql);
  echo "1";
  mysql_close();
  ?>