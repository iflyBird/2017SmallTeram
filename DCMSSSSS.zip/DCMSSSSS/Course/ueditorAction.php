<?php
include 'MySqlAdmin.php';
mysql_query("SET NAMES 'utf8'");

  $name=$_POST["name"];
  $time=$_POST["time"];
  $content=$_POST["content"];
  
  $sql = "insert into notice( noticeName,noticeTime,noticeInfor) values('$name','$time','$content')";
  mysql_query($sql);
  echo "1";
  mysql_close();
  ?>