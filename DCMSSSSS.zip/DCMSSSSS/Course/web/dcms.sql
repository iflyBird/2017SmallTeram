/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 100121
Source Host           : localhost:3306
Source Database       : dcms

Target Server Type    : MYSQL
Target Server Version : 100121
File Encoding         : 65001

Date: 2017-07-03 08:19:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for conresult
-- ----------------------------
DROP TABLE IF EXISTS `conresult`;
CREATE TABLE `conresult` (
  `Bianhao` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `appID` int(11) DEFAULT NULL,
  `grade` varchar(20) DEFAULT NULL COMMENT '成绩',
  `rank` varchar(20) DEFAULT NULL COMMENT '排名',
  `elseInfor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Bianhao`),
  KEY `appID` (`appID`),
  CONSTRAINT `conresult_ibfk_1` FOREIGN KEY (`appID`) REFERENCES `enlistresult` (`appID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of conresult
-- ----------------------------

-- ----------------------------
-- Table structure for contestinfor
-- ----------------------------
DROP TABLE IF EXISTS `contestinfor`;
CREATE TABLE `contestinfor` (
  `comID` int(11) NOT NULL AUTO_INCREMENT COMMENT '赛事编号',
  `comName` varchar(255) DEFAULT NULL COMMENT '赛事姓名',
  `comInfor` varchar(255) DEFAULT NULL COMMENT '赛事信息',
  `comTime` date DEFAULT NULL COMMENT '比赛时间',
  `comLevel` varchar(20) DEFAULT NULL COMMENT '赛事级别',
  `ID` int(11) DEFAULT NULL COMMENT '负责人工号',
  `startTime` date DEFAULT NULL COMMENT '开始报名的时间',
  `overTime` date DEFAULT NULL COMMENT '结束报名的时间',
  `comPlace` varchar(255) DEFAULT NULL COMMENT '比赛地点',
  `comBurget` varchar(20) DEFAULT NULL COMMENT '赛事预算',
  `comAppInfor` varchar(255) DEFAULT NULL COMMENT '赛事申请信息',
  `comSum` varchar(255) DEFAULT NULL COMMENT '赛事总结',
  `conAud` varchar(255) DEFAULT NULL COMMENT '赛事审核信息',
  PRIMARY KEY (`comID`),
  KEY `ID` (`ID`),
  CONSTRAINT `contestinfor_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `fuzereninfor` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of contestinfor
-- ----------------------------

-- ----------------------------
-- Table structure for enlistresult
-- ----------------------------
DROP TABLE IF EXISTS `enlistresult`;
CREATE TABLE `enlistresult` (
  `appID` int(11) NOT NULL AUTO_INCREMENT COMMENT '申请编号',
  `comID` int(20) NOT NULL COMMENT '赛事编号',
  `teamID` int(20) NOT NULL COMMENT '团队',
  `teaID` int(20) NOT NULL COMMENT '指导老师',
  `elseInfor` varchar(255) DEFAULT NULL COMMENT '备注',
  `state` varchar(25) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`appID`),
  KEY `comID` (`comID`),
  KEY `teamID` (`teamID`),
  KEY `teaID` (`teaID`),
  CONSTRAINT `enlistresult_ibfk_1` FOREIGN KEY (`comID`) REFERENCES `contestinfor` (`comID`),
  CONSTRAINT `enlistresult_ibfk_2` FOREIGN KEY (`teamID`) REFERENCES `team` (`teamID`),
  CONSTRAINT `enlistresult_ibfk_3` FOREIGN KEY (`teaID`) REFERENCES `teacherinfor` (`teaID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enlistresult
-- ----------------------------

-- ----------------------------
-- Table structure for fuzereninfor
-- ----------------------------
DROP TABLE IF EXISTS `fuzereninfor`;
CREATE TABLE `fuzereninfor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `fzrName` varchar(20) DEFAULT NULL,
  `fzrTel` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fuzereninfor
-- ----------------------------

-- ----------------------------
-- Table structure for manageinfor
-- ----------------------------
DROP TABLE IF EXISTS `manageinfor`;
CREATE TABLE `manageinfor` (
  `manID` int(20) NOT NULL COMMENT '管理员编号',
  `manName` varchar(8) DEFAULT NULL COMMENT '管理员姓名',
  `manSex` char(2) DEFAULT NULL COMMENT '管理员性别',
  `manTel` varchar(20) DEFAULT NULL COMMENT '管理员联系方式',
  `manYX` varchar(20) DEFAULT NULL COMMENT '管理员邮箱',
  `manPwd` varchar(20) DEFAULT NULL COMMENT '管理员登陆密码',
  PRIMARY KEY (`manID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manageinfor
-- ----------------------------
INSERT INTO `manageinfor` VALUES ('1001', '张兴', '男', '15755316377', '1440682157@qq.com', 'admin');
INSERT INTO `manageinfor` VALUES ('1002', '吴慎华', '男', '15755743256', '1440682157@qq.com', 'admin');
INSERT INTO `manageinfor` VALUES ('1003', '夏娟', '男', '15755316244', '15778943654@qq.com', 'admin');

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `newsID` int(11) NOT NULL AUTO_INCREMENT,
  `newsName` varchar(255) DEFAULT NULL,
  `newsTime` date DEFAULT NULL,
  `newsInfor` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`newsID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('11', '全国“挑战杯”相关知识问答', '2017-06-12', '<p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">1、什么是“挑战杯“全国大学生课外学术科技作品竞赛？</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">答：“挑战杯“全国大学生课外学术科技作品竞赛（简称”挑战杯“竞赛）是一项由共青团中央、中国科协、教育部、全国学联主办、国内著名大学和新闻单位联合发起并组织的全国性大型赛事，旨在全面展示我国高校成果，激发广大在校大学生崇尚科学、追求真知、勤奋学习、锐意创新、迎接挑战的精神，为国家培养跨世纪的创新人才。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">2、“挑战杯“竞赛的宗旨是什么？</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">答：崇尚科学、追求真知、勤奋学习、锐意进取、迎接挑战</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">3、“挑战杯” 竞赛的目的是什么？<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 答:引导和激励高校学生实事求是、刻苦钻研、勇于创新、多出成果、提高素质，并在此基础上促进高校学生课外学术科技活动的蓬勃开展，发现和培养一批在学术科技上有作为、有潜力的优秀人才。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">4、“挑战杯“在全国大学的影响怎样？</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 答：“挑战杯“全国大学生课外学术科技作品竞赛由共青团中央、中国科协、教育部、全国学联主办、国内著名大学和新闻单位联合发起组织并开展的，是一项具有导向性、示范性和权威性的全国科技竞赛活动，被誉为中国大学生学术科技的”奥林匹克“。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">5、“挑战杯“在中国大学的举办历史？</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 答：“挑战杯”每两年举办一届，自l989年以来已分别在清华大学、浙江大学、上海交通大学、武汉大学、南京理工大学、重庆大学、西安交通大学、华南理工大学、复旦大学、南开大学、北京航空航天大学、大连理工大学成功地举办了十二届</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">6、挑战杯如何参赛？</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 答：挑战杯已形成校级、省级、全国的三级赛事，参赛同学首先参加校内及省内的作品选拔赛，优秀作品报送全国组委会参赛。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">7、什么人可以参加“挑战杯”竞赛？<br/>　　答：凡在举办竞赛终审决赛的当年7月1日以前正式注册的全日制非成人教育的各类高等院校的在校中国籍专科生、本科生和硕士研究生、博士研究生（均不含在职研究生）都可申报作品参赛。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">8、参加“挑战杯”竞赛的申报参赛作品有什么要求？<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 答：申报参赛的作品必须是距竞赛申报日前两年内完成的学生课外学术科技或社会实践活动成果，可分为个人和集体申报作品。申报个人作品的，申报者必须承担申报作品60%以上的研究工作，作品鉴定证书、专利证书及发表的有关作品上的署名均应为第一作者，合作者必须是学生且不得超过两人；凡作者超过三人的项目或者不超过三人，但无法区分第一作者的项目，均须申报集体作品。集体作品除填写集体作品名称外，还要注明一位学历最高的作者为集体项目的代表，集体作品作者必须均为学生。凡有合作者的个人作品或集体作品，均按学历最高的作者划分本、专科生作品、硕士研究生作品或博士研究生作品。毕业设计和课程设计（论文）、学年论文和学位论文、国际竞赛上获奖的作品、获国家级奖励成果（含本竞赛主办单位参与举办的其它全国性竞赛的获奖作品）等不在申报范围之列。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">9、对参赛作品是否有特殊要求？<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 答：当参赛作品涉及下述内容时，必须由申报单位提供有关部门的证明材料，否则不予评审：<br/>动植物新品种的发现或培育，须有省级以上农科部门或科研院所开具证明；<br/>对国家保护动植物的研究，须有省级以上林业部门开具证明（证明该项研究的过程中未产生对所研究的动植物繁衍、生长不利的影响）；<br/>新药物的研究，须有卫生行政部门授权机构的鉴定证明；<br/>医疗卫生研究须通过专家鉴定，并最好附上在公开发行的专业性杂志上发表过的文章；<br/>涉及燃气用具等与人民生命财产安全有关用具的研究，须有国家相应行政部门授权机构的认定证明。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">10、 有哪些作品不在申报范围之列？<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 答：毕业设计和课程设计（论文）、学年论文和学位论文、国际竞赛中获奖的作品、获国家级奖励成果（含本竞赛主办单位参与举办的其它全国性竞赛的获奖作品）等均不在申报范围之内。<br/></span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp;</span></p>');
INSERT INTO `news` VALUES ('12', '第十五届“挑战杯”全国大学生课外学术科技作品竞赛第二次筹备工作推进会顺利召开', '2017-05-26', '<p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp; 2016年11月28日下午，团中央学校部杜汇良部长一行赴上海大学调研第十五届“挑战杯”全国大学生课外学术科技竞赛筹备情况。团中央学校部副部长宋来，团中央学校部全国学联办公室主任柏贞尧，上海大学党委书记罗宏杰，上海大学党委副书记、副校长徐旭，上海市教委、市科委、市科协、市台办、团市委以及上海大学相关部门相关同志参加了本次调研。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp;&nbsp;杜汇良一行考察了上海大学无人艇研究院，两位“杰青”教授罗均、谢少荣介绍了由青年专家学者与研究生共同组成的研究团队，克服多种困难，专注于无人艇技术创新，从海图绘制到海底探测、海洋环境监测等方面矢志科技报国，服务国家战略的情况。随后，参观了上海大学省部共建“高品质特殊钢冶金与制备国家重点实验室”，并对材料学院基层团建以“挑战杯”课外学术科技竞赛项目为抓手，致力创新人才培养工作给予充分肯定。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp;&nbsp;&nbsp;下午3：00，第十五届“挑战杯”全国大学生课外学术科技作品竞赛第二次筹备工作推进会在宝山校区乐乎新楼2号楼思源厅召开。会议由团中央学校部副部长宋来主持。校团委书记许烁作了第十五届“挑战杯”竞赛筹备工作情况汇报，力求落实此次办赛“三个结合”和“三个提升”的具体要求。“三个结合”即在大赛的筹备和实施过程中，更好实现创新与创业相结合，搭建平台和促进实践相结合，立足上海与服务全国战略相结合。“三个提升”即进一步提升国际化水平，进一步提升学生参与度，进一步提升挑战杯的层次和水平。汇报提出了“聚焦育人工作，服务国家战略，立足上海发展”的办赛目标，围绕赛事主题介绍了“1+2+X”的主体赛事、专项赛事、邀请赛以及主题延伸活动，介绍了前期筹备工作进展以及下一阶段的工作重点。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 校党委副书记、副校长徐旭在致辞中表示，本次办赛是学校建设高水平大学进程中的一次契机，学校将主动对接国家战略，对接上海市行业产业需求，希望各级部门给予指导和支持，协助学校统筹资源，稳步推进各项工作。校党委书记罗宏杰指出，上海大学自获得“挑战杯”竞赛承办权以来，紧密围绕办赛宗旨，坚持顶层设计，强化科学管理，学校各部门通力合作开展赛事筹备工作，希望能够进一步扩大赛事覆盖面和参与度，提升“挑战杯”影响力。会上，上海市相关委办局负责同志以及上海大学各职能部门负责同志分别发言表示将结合部门工作特点，共同推进，全力支持配合”挑战杯”筹办工作。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 杜汇良指出，第十五届“挑战杯”竞赛的前期筹备工作卓有成效，在未来的工作中组委会要注重总结“挑战杯”近30年来的办赛成果，在传承历史的基础上把握时代特征和使命；他强调，赛事要突出学生的主体性，面向海内外体现学生的广泛参与，将“挑战杯”竞赛办成“双创”文化的嘉年华；他希望筹备工作组明晰工作任务，建立完善的工作机制，细化优化各项方案，落实好下一步筹备工作，相信上海大学会成功举办一届有特点、有亮点的“挑战杯”赛事。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 本次调研活动系统总结了第十五届“挑战杯”竞赛办赛前期筹备工作，明确了办赛理念、主题、任务等，为下一步筹备工作凝聚了共识，指明了方向。</span></p><p></p>');
INSERT INTO `news` VALUES ('13', '南阳理工学院第三届大学生程序设计大赛结束', '2017-06-12', '<p style=\"margin: 0px 0px 20px; padding: 0px; color: rgb(0, 0, 0); text-transform: none; line-height: 2; text-indent: 2em; letter-spacing: normal; font-family: Tahoma, Helvetica, Arial, 宋体, sans-serif; font-size: 16px; font-style: normal; font-weight: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><span style=\"font-size: 20px;\"><strong style=\"margin: 0px; padding: 0px;\">本网讯</strong>（特约记者/<strong style=\"margin: 0px; padding: 0px;\">张哲杨双</strong>）6月11日，由学生处主办，软件学院承办的我校第三届大学生程序设计大赛结束。经过激烈角逐，来自计算机学院的2支代表队获得专业A组一等奖，来自计算机学院、软件学院等10支代表队获得专业B组一等奖。</span></p><p style=\"margin: 0px 0px 20px; padding: 0px; color: rgb(0, 0, 0); text-transform: none; line-height: 2; text-indent: 2em; letter-spacing: normal; font-family: Tahoma, Helvetica, Arial, 宋体, sans-serif; font-size: 16px; font-style: normal; font-weight: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><span style=\"font-size: 20px;\">本次比赛分初赛和决赛两个阶段进行。初赛历时一个半月，举办了100余场比赛，近5000人参加，有162支代表队486名同学进入决赛。平顶山学院、郑州轻工业学院、南阳师范学院和河南工业职业技术学院也选派了代表队参加比赛。</span></p><p style=\"margin: 0px 0px 20px; padding: 0px; text-align: center; color: rgb(0, 0, 0); text-transform: none; line-height: 2; text-indent: 2em; letter-spacing: normal; font-family: Tahoma, Helvetica, Arial, 宋体, sans-serif; font-size: 16px; font-style: normal; font-weight: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><img alt=\"(图)南阳理工学院第三届大学生程序设计大赛结束 中国财经新闻网 www.prcfe.com\" src=\"/ueditor/php/upload/image/20170702/1498955488110983.jpg\"/></p><p style=\"margin: 0px 0px 20px; padding: 0px; color: rgb(0, 0, 0); text-transform: none; line-height: 2; text-indent: 2em; letter-spacing: normal; font-family: Tahoma, Helvetica, Arial, 宋体, sans-serif; font-size: 16px; font-style: normal; font-weight: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><span style=\"font-size: 20px;\">副校长肖泽昌在总决赛开幕式上指出，作为我校重点打造的“五项团学工程”的重要组成工程，大学生程序设计大赛是我校学风建设重点培育工程项目，重在拓展大学生的学习实践运用能力，开阔大家视野，锻炼意志品质。（校对/<strong style=\"margin: 0px; padding: 0px;\">肖邓华</strong>编辑/<strong style=\"margin: 0px; padding: 0px;\">王虎</strong>编审/<strong style=\"margin: 0px; padding: 0px;\">罗新宇</strong>）</span></p><p></p>');
INSERT INTO `news` VALUES ('14', '第十二届同济大学大学生程序设计竞赛落幕', '0000-00-00', '<p style=\"color: rgb(51, 51, 51); text-transform: none; text-indent: 2em; letter-spacing: normal; font-family: Tahoma, Arial, Helvetica, Verdana, 宋体; font-size: 13.33px; font-style: normal; font-weight: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><span style=\"font-size: 20px;\">&nbsp;&nbsp; 4月12日，同济大学大学生电子信息科技创新基地“E海扬帆”科技节系列活动之第十二届同济大学大学生程序设计竞赛在嘉定校区计算机中心落下帷幕。&nbsp;<br/>　　本次大学生程序设计竞赛由我校教务处主办，电子与信息工程学院承办，旨在借助竞赛普及计算机程序设计活动，提高大学生计算机程序设计水平和运用计算机分析问题、解决问题的能力。此次校内竞赛也将为我校组队参加第40届ACM国际大学生程序设计竞赛亚洲区预选赛选拔队员、锻炼队伍。&nbsp;<br/>　　此次竞赛得到了全校学生的积极参与，来自电信、软件、机械、汽车、交通、土木、海洋、经管、航力、中德工程、理学院等11个学院的130余支队伍报名参赛。经过网络预选赛，共有70支队伍进入了最后的决赛。经过5个小时的激烈角逐，最终5支队伍脱颖而出获得决赛一等奖，10支代表队获得二等奖，20支代表队获得了三等奖。另有一组发挥出色的女生组合斩获“最佳女生队”称号。</span></p><p style=\"text-align: center; color: rgb(51, 51, 51); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: Tahoma, Arial, Helvetica, Verdana, 宋体; font-size: 13.33px; font-style: normal; font-weight: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><a style=\"color: rgb(51, 51, 51); font-family: Tahoma, Arial, Helvetica, Verdana, 宋体; text-decoration: none;\" href=\"http://photo.tongji.edu.cn/themes/11/userfiles/images/2015/4/14/650/svi4feqvd6fo54f.jpg\"><img title=\"20150413071911_29758\" alt=\"20150413071911_29758\" src=\"/ueditor/php/upload/image/20170702/1498955582868424.jpg\"/></a></p><p style=\"color: rgb(51, 51, 51); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: Tahoma, Arial, Helvetica, Verdana, 宋体; font-size: 13.33px; font-style: normal; font-weight: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong style=\"font-family: Tahoma, Arial, Helvetica, Verdana, 宋体;\"></strong></p><p style=\"color: rgb(51, 51, 51); text-transform: none; text-indent: 2em; letter-spacing: normal; font-family: Tahoma, Arial, Helvetica, Verdana, 宋体; font-size: 13.33px; font-style: normal; font-weight: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><strong style=\"font-family: Tahoma, Arial, Helvetica, Verdana, 宋体;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong><span style=\"font-size: 20px;\"><strong style=\"font-family: Tahoma, Arial, Helvetica, Verdana, 宋体;\">另讯：<br/></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4月10日，同济大学信息融合创新发展论坛2015年年会在嘉定校区济人楼举行。恰逢85级工业电气自动化专业校友毕业25周年。校友们从四面八方回到母校，在此欢聚一堂。学院对远道而来的校友们表示热烈的欢迎，介绍了近年来控制科学与工程系的建设、学科发展及人才培养等各方面所取得的成就，同时向校友们为学院的发展所做出的贡献表示真诚的感谢，希望校友们经常回校看看，加强校企之间项目及人才的合作交流。校友们纷纷表示今后会加强与母校的联络和沟通，为母校、为学院的发展贡献自己的力量。</span></p><p></p>');
INSERT INTO `news` VALUES ('15', '全程“烧脑” 大学生程序设计大赛亮出“极客范儿”', '2016-11-21', '<p class=\"otitle\" style=\"font: 18px/32px &quot;Microsoft Yahei&quot;; margin: 32px 0px 0px; padding: 0px; text-align: justify; color: rgb(64, 64, 64); text-transform: none; text-indent: 2em; letter-spacing: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; （原标题：全程“烧脑” 大学生程序设计大赛亮出“极客范儿”）</p><center><img title=\"\" id=\"34726076\" alt=\"全程“烧脑” 大学生程序设计大赛亮出“极客范儿”\" src=\"http://cms-bucket.nosdn.127.net/catchpic/b/b3/b39e86ae1a9a0c7181c4c4dbfe8f5d0f.jpg?imageView&thumbnail=550x0\"/></center><center><span style=\"font-size: 18px;\">参赛选手们 重庆工程学院供图 华龙网发</span></center><center><center><img title=\"\" id=\"34726115\" alt=\"全程“烧脑” 大学生程序设计大赛亮出“极客范儿”\" src=\"http://cms-bucket.nosdn.127.net/catchpic/9/9e/9e7525b199c1b3b188ded18b65382d6c.jpg?imageView&thumbnail=550x0\"/></center><center>志愿者热情接待 重庆工程学院供图 华龙网发</center><center><center><img title=\"\" id=\"34726122\" alt=\"全程“烧脑” 大学生程序设计大赛亮出“极客范儿”\" src=\"http://cms-bucket.nosdn.127.net/catchpic/b/b0/b09797662fd60c50ff18d3d47cad0a14.jpg?imageView&thumbnail=550x0\"/></center><center><span style=\"font-size: 18px;\">比赛现场 重庆工程学院供图 华龙网发</span></center><center><center><img title=\"\" id=\"34726126\" alt=\"全程“烧脑” 大学生程序设计大赛亮出“极客范儿”\" src=\"http://cms-bucket.nosdn.127.net/catchpic/7/75/75bf78e0e361b268cccd5b35402fbc5e.jpg?imageView&thumbnail=550x0\"/></center><center><span style=\"font-size: 18px;\">重庆大学团队获得优胜 重庆工程学院供图 华龙网发</span></center></center></center></center><p style=\"font: 18px/32px &quot;Microsoft Yahei&quot;; margin: 32px 0px 0px; padding: 0px; text-align: justify; color: rgb(64, 64, 64); text-transform: none; text-indent: 2em; letter-spacing: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><strong>华龙网11月21日9时10分迅（王玟兮）11月19日，重庆市第七届大学生程序设计大赛总决赛在重庆工程学院成功举行。比赛分为初赛和决赛两个阶段。比赛过程中，参赛学生专注于自己的答题项目，在小团队中展开着没有硝烟的讨论，赛场气氛紧张激烈。</strong></p><p style=\"font: 18px/32px &quot;Microsoft Yahei&quot;; margin: 32px 0px 0px; padding: 0px; text-align: justify; color: rgb(64, 64, 64); text-transform: none; text-indent: 2em; letter-spacing: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><strong>经过激烈的角逐，比赛共产生特等奖1个，一等奖11个，二等奖16个，三等奖50个。大赛团体总分奖1个，优秀组织奖4个。重庆大学的团队获本届大学生程序设计大赛特等奖与团体总分奖，重庆工程学院等四所高校获得优秀组织奖。重庆市计算机学会理事长朱庆生、重庆工程学院副校长程昌华教授等领导及嘉宾出席了比赛颁奖典礼。</strong></p><p style=\"font: 18px/32px &quot;Microsoft Yahei&quot;; margin: 32px 0px 0px; padding: 0px; text-align: justify; color: rgb(64, 64, 64); text-transform: none; text-indent: 2em; letter-spacing: normal; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\"><strong>重庆市大学生程序设计大赛每年由不同的承办单位承办。颁奖仪式后，本届大赛承办单位代表将赛旗交接与下届大赛承办单位代表。重庆工程学院副校长程昌华代表本届大赛承办单位将赛旗交与朱庆生理事长，再由朱庆生理事长将赛旗交付于第八届大学生程序设计大赛承办单位重庆工商职业学院代表龚卫教授。</strong></p><p></p>');
INSERT INTO `news` VALUES ('16', '上海交大获国际大学生程序设计竞赛金奖', '2016-05-21', '<p style=\"text-align: center;\"><strong>上海交大ICPC大赛获得金奖 中国编程力国际上啥水平？</strong></p><p><strong>&nbsp;</strong></p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20170702/1498955913152633.jpg\"/></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">新华网北京5月21日电 由美国计算机协会（ACM）主办的第40届国际大学生程序设计竞赛（ICPC）总决赛19日在泰国普吉岛上演“脑力激荡”的巅峰之战。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">上海交通大学队从128支决赛队伍中“杀出重围”获得2016年ICPC大赛金奖，但以与冠军队圣彼得堡国立大学相差7分的劣势，屈居总分第二。</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">“随计算机科技在全球的迅速发展，ICPC大赛也从一开始的北美独大，变成了如今亚洲（主要是东亚）、欧洲（主要是俄罗斯和东欧）与美国分庭抗礼的局面，”余勇教授如是说。</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20170702/1498955917718931.jpg\"/></p><p>&nbsp;</p><p style=\"text-align: center; text-indent: 2em;\"><span style=\"font-size: 18px;\">实际上，今年有上海交通大学、复旦大学、清华大学、中山大学等16支来自中国大陆和香港中文大学、台湾大学等3支来自港台地区的高校团队进入ICPC总决赛。</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20170702/1498955918451360.jpg\"/><br/>&nbsp;</p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">获得2016年ICPC大赛冠军的圣彼得堡国立大学接受颁奖</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">今年的冠军得主圣彼得堡国立大学与上海交通大学同样解出了11道题，但因在综合用时方面比上交大少了7分钟而最终胜出。另一支来自中国的高校队复旦大学总分排名第12，获得铜奖。</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20170702/1498955918513584.jpg\"/></p><p>&nbsp;</p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">纵览总分排行榜，前12名就有5支队伍来自俄罗斯，另有3支分别来自波兰和乌克兰。28支参加决赛的美国高校队仅有哈佛大学和麻省理工学院进入前12。</span></p><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">自1996年ICPC进入中国以来，上海交大19次杀入总决赛，3次夺冠、2次亚军，是亚洲的最好成绩。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">余勇教授一语道破天机：“编程中，数学能力的高低起了决定性作用。”所以，你懂的。</span></p><p>&nbsp;</p><p style=\"text-align: center;\"><strong>参加ICPC大赛有什么好处？</strong></p><p>&nbsp;</p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20170702/1498955919239385.jpg\"/></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">业界和学界普遍认可参加ICPC大赛的价值。对学生来说，有ICPC的参赛经历对今后在计算机行业内的职业前景是个巨大的“加分项”。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">不过，“最强大脑”们在同一舞台上的碰撞和交流或许才更有意义。今年的决赛圈中还出现了3支来自战火纷飞的叙利亚的大学团队。</span></p><p>&nbsp;</p><p><br/>&nbsp;</p><p style=\"text-align: center;\"><span style=\"font-size: 18px;\">据主办方介绍，ICPC的参赛者有机会与赞助商IBM的技术专家进行面对面的交流，充分了解整个行业的发展趋势及专业发展。</span></p><p>&nbsp;</p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20170702/1498955919909820.jpg\"/></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">“作为本次大赛的首席赞助商，IBM 希望可以帮助世界顶级的编程学生提升专业技能，让他们接触到诸如云计算和认知智能等领先技术，并让他们对编程更加感兴趣，”IBM 开放技术和 IP 部ACM-ICPC 赞助执行官和总监杰拉德·兰恩说，“随着世界上越来越多的企业转向云计算等先进技术来转型他们的企业运作方式，他们将需要更多如本次大赛选手们一样有才华的开发者。”（记者林晶，编辑鲁豫，新华国际客户端报道）</span></p><p></p>');
INSERT INTO `news` VALUES ('17', '2017\"中国软件杯\"大学生软件设计大赛火热报名中', '2017-06-01', '<p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style=\"font-family: 宋体,SimSun; font-size: 24px;\">六年磨一剑。</span></span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　阳春三月，伴着醉人的春风，第六届“中国软件杯”大学生软件设计大赛（以下简称大赛）报名工作也在如火如荼地进行着。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">第六届&quot;中国软件杯&quot;大学生软件设计大赛</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　产教融合育软件精英</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　有了前五届的沉淀与积累，今年软件学子们对大赛的关注度持续高涨。开学伊始，大赛的官网点击率居高不下，虽然赛题还未公布完毕，但这并不影响同学们的参与热情。据大赛组委会韩老师介绍，有的学校因连续参加了五届大赛，对赛事流程已非常熟悉，放寒假前，就已组织学生召开了参赛动员大会；寒假还未过完，就已经有不少同学打电话询问大赛的报名事宜和部分赛题的情况，并利用寒假组队为参加大赛做准备；也有去年参加大赛未取得名次的同学雄心勃勃，早早开始准备今年的比赛。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　大赛是由工业和信息化部、教育部、江苏省人民政府联合主办的面向全国高等（高职）院校及广大海外院校在校生的一项纯公益性软件设计类赛事，大赛秉承“政府指导、企业出题、高校参与、专家评审、育才选才”的方针，以“催生多重效应，引领产业创新”为宗旨，创造了产学融合的新平台。经过前期的赛题征集、赛题评审等紧张筹备，2017年3月1日参赛报名工作正式启动。目前大赛赛题已在网上公布，全国高等（高职）院校学生于3月1日-4月30日均可登录大赛官网（</span><a style=\"font-size: 18px; text-decoration: underline;\" href=\"http://www.cnsoftbei.com\"><span style=\"font-size: 18px;\">www.cnsoftbei.com</span></a><span style=\"font-size: 18px;\">）进行网上选题与报名。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　大赛从2012年至今已成功举办了五届，从破土而出到蓬勃发展，大展在成长中不断创新：2012年第一届大赛开启“两部一省”共同主办的新篇章，为圆产业强国梦搭建广阔平台；2013年第二届大赛赛题反映前沿技术动态，成为引领产业发展风向标；2014年第三届大赛探索促进产教深度融合之路，培育创新软件人才；2015年第四届大赛开始举办投融资对接会，促进优秀作品产业化；2016年第五届大赛迎来国际参赛选手，大赛走向国际化；2017年第六届大赛，创新的脚步仍在继续。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　聚焦行业热点</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　技术难点 应用痛点</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　把产业发展的热点问题和技术难点经过提炼和浓缩形成竞赛题目是大赛始终坚持的做法。这样才能更有效地促进产教融合，真正做到以赛促改，使高校软件人才培养方向与产业发展所需有效衔接。今年大赛的赛题紧扣行业热点，紧跟技术难点，直击应用痛点。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　<span style=\"color: rgb(255, 0, 0); font-size: 18px;\"><strong>热点一 人工智能</strong></span></span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　近几年，高科技公司纷纷斥巨资在人工智能领域布局。如果说互联网变革了人类的生活方式，那么人工智能将会切实带动整个社会生产力的提高，引领新一轮科技浪潮的发展。不夸张地说，它将掀起一场新的工业革命。用人工智能解决人口老龄化带来的社会问题，可谓一举多得。来自东软的出题专家朱春雷认为，人口老龄化社会子女少，如果能够通过技术手段提高老人生活自理能力，让老人过上高品质的晚年生活，减轻子女的护理压力，缓解社会医疗资源紧张等社会现实问题，将是十分有意义的。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　尽管在下棋对弈等情况下人工智能可以做得很好，但需要大量的后台资源支持。针对目前人工智能软件算法还不够完善，硬件处理能力还不够强，整体性能还不强，硬件还不能做得很小巧等技术难题，东软设计了“智能老人辅助系统”赛题。要求参赛学生设计良好便捷的人机接口，方便老人使用。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　“对于参赛学生来说，这个题目的难点在于人工智能算法的运用。人工智能一直在深入发展，技术发展较快，但人工智能的最终目标是代替人类或完成人类无法完成的任务，离这个目标的实现目前还有很大距离；另外目前学生普遍侧重软件学习，不重视硬件方面的学习，硬件学习要有长期的知识和技能的积累，通过这样一个软硬结合的题目可以激发学生的学习兴趣。”</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　<span style=\"color: rgb(255, 0, 0); font-size: 18px;\"><strong>热点二 区块链</strong></span></span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　区块链同样是不能错过的行业热点。它因为具有去中心化的信任、稳定可靠、不需要第三方介入的强安全共识机制、公开透明和不可篡改性等特征，被广泛进行研究和应用。本届大赛产生了“基于区块链的电子证照库应用”这一赛题，要求学生充分利用区块链的可追溯、共享账本、不对称加密的特征来建设一个电子证照库。赛题新颖，充分贴合了时代发展的需求。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　江苏星网软件出题专家陈雪勇谈到：“区块链目前来说属较为新型的应用模式，希望利用区块链去中心化的理念在技术层面建立相互的信任关系。”这一赛题对参赛学生来说颇具挑战性。“区块链是通过分布式存储、共识机制、加密算法等组成一套技术体系。比特币作为通用的互联网货币，就是基于区块链技术发展起来的，通过以太坊技术实现互信。”陈雪勇解释说。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　<span style=\"color: rgb(255, 0, 0); font-size: 18px;\"><strong>热点三 大数据</strong></span></span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">为推动大数据领域技术、产品、应用创新，大赛组委会拟举办面向大数据领域的专项赛事——“中国软件杯”大数据大赛。大赛通过发现业务痛点、挖掘数据价值，寻求优化方案，推动大数据领域创业创新，鼓励高校大学生群体及来自互联网/软件类企业的算法工程师/软件工程师共同就一到多个业务场景建立模型优化算法，充分利用既有数据及组委会公开数据给出数字化运营的最优方案。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　此外，第六届大赛在赛题种类上更加丰富，有更多细分版块出现。结合当下时代发展的热点和出题企业的需求，分类设计了安全可靠专题赛以及开源专题赛等专业板块小专题赛。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　本次大赛共计收到67家企业提交的136道赛题。经过专家组评审，已公布本科组赛题8道，高职组赛题3道。其中本科组的题目有：民航机票代理市场的预测及可视化、基于WiFi探针的商业大数据分析技术、智能老人助理系统、企业增值税发票数据分析系统、版式文档（OFD）排版原型系统、基于区块链的电子证照库应用、数据众包采集系统和“无微不至”的阅读伴侣。高职组的题目有：基于互联网大数据的事件智能抓取和画像、基于聊天机器人的数据查询系统和智能路灯系统。截止到记者发稿时，民航机票代理市场的预测及可视化成为关注度最高的赛题。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　构建双创生态体系</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　推进大众创业、万众创新，是发展的动力之源，也是富民之道、公平之计、强国之策。大赛是落实创新人才培养政策的重要举措。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　大赛已探索出产教互动融合，共育创新人才的新模式。企业专家出题，联合高校专家评审，开创投资融对接会，加速了科研成果到产品应用的转化。大赛已成为激励软件人才创新创业的平台，是建立健全产教融合、校企合作的人才培养机制的重要途径；强化了人才培养链与产业链、创新链有机衔接；对高校面向产业发展需求，优化专业设置和人才培养方案起到积极促进作用。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　据悉，今年大赛将依托双创平台，举办“中国软件杯”大学生双创相关的系列活动。</span></p><p style=\"text-indent: 0em;\"><span style=\"font-size: 18px;\">　　大赛组委会将进一步扩大赛事影响力、优化赛事流程，推进大赛国际化进程、秉承公正公平公开的原则，早日把大赛办成软件行业最具国际影响力的赛事。');
INSERT INTO `news` VALUES ('18', '大学生变身“专利哥” 四年获上百项专利', '2017-01-12', '<p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">大学四年，申请专利142项，获得授权证书的发明专利有15项，实用新型专利有90项……中国计量学院现代科技学院一名叫李群星的同学，交出了一份特殊的毕业“成绩单”。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">两次获得校园吉尼斯之星——创新创业达人的李群星，被同学和老师私下称为“专利哥”。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">看到摊开占了足足有一张桌面的专利证书，他笑着说，那只是所有证书的十分之一。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">记者在讶然之余问及原因，他说，主要缘于刚入大学时的一次新老生交流会，通过学长的介绍，让他对申请专利产生了浓厚的兴趣。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">李群星的第一个专利是一种同时将风力传送到各个方向的电风扇，他告诉记者，为了完成这个发明，他通过查资料、写材料，花了整整一个月才完成。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">之后，李群星的设计发明之路便一发而不可收，如可触屏控制电容屏式手机的手套，卫生杯用滤茶器，可自行站立的扫把，一种用餐时的餐盘与加热垫的组合，或者刀刃可旋转的菜刀……</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">“我有空的时候喜欢瞎琢磨，有时候不经意间发现身边某些东西存在缺陷，或是看到一些新闻事故，我就会想怎么可以避免同样的问题出现。”李群星如是说。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">&nbsp;有段时间，他经常看到新闻里有司机误踩油门引发事故，于是就想到了可以利用电子感应原理，做一个防误踩油门的汽车自动装置。可喜的是，该装置现已进入实质审查、答辩阶段。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">用同学的话说，“李群星是属于脑子转得特别快，自学能力特别强的人。”</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">“专利哥”李群星还有一个创业梦。从大三开始，李群星就已经开始考虑，如何将他的专利成果投入推广的问题。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">于是，在2014年，他和几个志同道合的同学一起创办了“杭州追猎科技有限公司”。他说：“我们创办这个公司，就是基于专利创办，也是为专利服务的。”</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">今年4月，公司已经迎来了“开门红”，与杭州某公司签订了共计150套价值8万元的销售合同，同时与某代理商签订了产品销售代理协议，计划将产品推向浙江省以外的其他地区市场。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">“聪明你的房间，智能你的管理，让可见光通信走进我们的生活，让科技改变生活。这是我们公司的口号，也是我们的终极追求。”他说</span></p><p></p>');
INSERT INTO `news` VALUES ('19', '阿里巴巴牵手ACM掀大学生程序设计大赛热潮', '2017-04-19', '<p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">4月19日消息，记者近日获悉，世界上公认的规模最大、水平最高的国际大学生程序设计竞赛ACM/ICPC与阿里巴巴集团达成合作，双方将携手在中国近10所高校举办ACM/ICPC程序设计精英赛，给中国优秀技术人才提供更多学习交流的机会，搭建一个展示自己实力的舞台。 ACM/ICPC是世界上公认的规模最大、水平最高的国际大学生程序设计竞赛，被誉为世界大学生的计算机奥林匹克竞赛。该项赛事的举办旨在使大学生运用计算机来充分展示自己分析问题和解决问题的能力。竞赛难度大、含金量高，每届比赛中皆是精英荟萃、新才辈出，从1970年至今在全世界已成功举办30多届。ACM国际大学生程序设计竞赛已成为世界各国大学生最具影响力的国际级计算机类赛事，是广大爱好计算机编程的大学生展示才华的舞台，也直接体现著名大学计算机教育成果，同时还是信息企业与世界顶尖计算机人才对话的最好机会。</span></p><p style=\"text-indent: 2em;\"><span style=\"font-size: 18px;\">记者了解到，从2010年开始，阿里巴巴集团便成为ACM/ICPC中国赛区的战略合作伙伴。在阿里巴巴集团，本身就汇聚了大批一流编程高手；这次与ACM/ICPC合作，希望给予高校编程高手一个机会，促进技术的分享与交流。 各个高校精英赛决赛的获胜者，除了将有机会得到三万元现金奖励，还能获得阿里巴巴集团校园招聘的特别通行证。首站成都电子科技大学校园赛异常火爆，仅报名参加的学生就超过千名。 “ACM/ICPC程序设计竞赛本身就非常知名，同时又能通过这个途径接触最新的互联网技术，并有机会进入到全球最大的电子商务公司工作，机会非常诱人。”参加首站比赛的电子科技大学学生小林告诉记者。 据悉，精英赛将在国内近10所知名院校展开，包括浙江大学、中国科学技术大学、华中科技大学、华南理工大学、哈尔滨工业大学、北京邮电大学、西安交通大学、电子科技大学等，比赛分为网络报名、网络初赛、现场决赛三个步骤。通过校园精英赛决出的优胜者，将于7月在阿里巴巴集团杭州总部进行总决赛。</span></p><p></p>');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `noticeID` int(11) NOT NULL AUTO_INCREMENT,
  `noticeName` varchar(5000) DEFAULT NULL,
  `noticeTime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `noticeInfor` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`noticeID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('1', '挑战杯比赛', '2017-07-02 01:00:00', null);
INSERT INTO `notice` VALUES ('2', '安徽省大学生程序设计大赛', '2017-07-02 00:59:26', '');
INSERT INTO `notice` VALUES ('3', '关于举办我校第十二届大学生程序设计竞赛', '2017-07-02 00:59:40', '');
INSERT INTO `notice` VALUES ('4', '第六届大赛', '2017-07-02 01:00:16', '');
INSERT INTO `notice` VALUES ('5', 'ACM校赛 | 大学生程序设计大赛', '2017-07-02 01:00:23', '');
INSERT INTO `notice` VALUES ('6', '国际专项赛', '2017-07-02 01:00:41', '');
INSERT INTO `notice` VALUES ('7', '互联网+大赛', '2017-07-02 01:00:00', null);

-- ----------------------------
-- Table structure for outpeo
-- ----------------------------
DROP TABLE IF EXISTS `outpeo`;
CREATE TABLE `outpeo` (
  `outID` int(11) NOT NULL AUTO_INCREMENT COMMENT '外来',
  `outName` varchar(20) DEFAULT NULL,
  `outPwd` varchar(20) DEFAULT NULL,
  `outTel` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`outID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of outpeo
-- ----------------------------
INSERT INTO `outpeo` VALUES ('1', '李迅', '123', '15755312478');
INSERT INTO `outpeo` VALUES ('2', '47', '47', 'null');
INSERT INTO `outpeo` VALUES ('3', '447', '123', 'null');
INSERT INTO `outpeo` VALUES ('4', '222', '222', 'null');

-- ----------------------------
-- Table structure for studentinfor
-- ----------------------------
DROP TABLE IF EXISTS `studentinfor`;
CREATE TABLE `studentinfor` (
  `stuID` int(20) NOT NULL AUTO_INCREMENT COMMENT '学号',
  `stuName` varchar(10) DEFAULT NULL COMMENT '学生姓名',
  `stuSex` char(2) DEFAULT NULL COMMENT '性别',
  `stuBirth` date DEFAULT NULL COMMENT '生日',
  `stuTel` varchar(20) DEFAULT NULL COMMENT '电话',
  `stuYX` varchar(20) DEFAULT NULL COMMENT '邮箱',
  `stuPro` varchar(20) DEFAULT NULL COMMENT '专业',
  `stuClass` varchar(25) DEFAULT NULL COMMENT '班级',
  `stuXueYuan` varchar(25) DEFAULT NULL COMMENT '学院',
  `stuPwd` varchar(20) DEFAULT NULL COMMENT '密码',
  PRIMARY KEY (`stuID`)
) ENGINE=InnoDB AUTO_INCREMENT=2017060104 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of studentinfor
-- ----------------------------
INSERT INTO `studentinfor` VALUES ('2017060101', '夏娟', 'on', '1960-01-01', '444', '4444', '软件工程', '1507', '安徽信息工程', '789');
INSERT INTO `studentinfor` VALUES ('2017060102', '张兴', '男', '1995-09-23', '15755316377', '1440682157@qq.com', '软件工程', '1503', '安徽信息工程', '123');
INSERT INTO `studentinfor` VALUES ('2017060103', '吴慎华', '男', '1996-08-07', '15733214789', '1440682157@qq.com', '软件工程', '1503', '安徽信息工程', '123');

-- ----------------------------
-- Table structure for teacherinfor
-- ----------------------------
DROP TABLE IF EXISTS `teacherinfor`;
CREATE TABLE `teacherinfor` (
  `teaID` int(50) NOT NULL AUTO_INCREMENT COMMENT '教师工号',
  `teaName` varchar(8) DEFAULT NULL COMMENT '姓名',
  `teaSex` char(2) DEFAULT NULL COMMENT '性别',
  `teaTel` varchar(20) DEFAULT NULL COMMENT '教师电话',
  `teaYX` varchar(20) DEFAULT NULL COMMENT '教师邮箱',
  `teaXueYuan` varchar(20) DEFAULT NULL COMMENT '所在学院',
  `teaPost` varchar(50) DEFAULT NULL COMMENT '职务',
  `teaPS` varchar(50) DEFAULT NULL COMMENT '备注',
  `teaPwd` varchar(20) NOT NULL COMMENT '登录密码',
  `teaPro` varchar(20) NOT NULL,
  PRIMARY KEY (`teaID`,`teaPro`)
) ENGINE=InnoDB AUTO_INCREMENT=1006 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacherinfor
-- ----------------------------
INSERT INTO `teacherinfor` VALUES ('1001', '张云玲', 'on', '15747893214', '14465477892@qq.com', '安徽信息工程学院', '讲师', '美女老师', 'admin', '计算机');
INSERT INTO `teacherinfor` VALUES ('1002', '伍岳', 'on', '15787963214', '1478478631@qq.com', '安徽信息工程学院', '讲师', '帅哥', 'admin', '计算机科学与技术');
INSERT INTO `teacherinfor` VALUES ('1003', '范绍兴', 'on', '1477894566214', '14787965413@qq.com', '安徽信息工程学院', '辅导员', '帅', 'admin', '教育心理学');
INSERT INTO `teacherinfor` VALUES ('1004', '吴慎华', 'on', '17527353763', '5735736', '安徽信息工程学院', '讲师', '帅', 'admin', '计算机科学与技术');
INSERT INTO `teacherinfor` VALUES ('1005', '孙立', '男', null, '11', '安徽信息工程学院', '讲师', '帅', 'admin', '计算机科学与技术');

-- ----------------------------
-- Table structure for team
-- ----------------------------
DROP TABLE IF EXISTS `team`;
CREATE TABLE `team` (
  `teamID` int(11) NOT NULL COMMENT '团队编号',
  `teamName` varchar(20) NOT NULL COMMENT '团队名',
  `captainID` varchar(20) NOT NULL COMMENT '组长学号',
  `member1ID` varchar(20) DEFAULT NULL,
  `member2ID` varchar(20) DEFAULT NULL,
  `member3ID` varchar(20) DEFAULT NULL,
  `member4ID` varchar(20) DEFAULT NULL,
  `member5ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`teamID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of team
-- ----------------------------
INSERT INTO `team` VALUES ('0', '11', '11', '11', '11', null, null, null);
INSERT INTO `team` VALUES ('1', '老虎队', '1001', '1', '2', '3', '4', '5');
INSERT INTO `team` VALUES ('2', '老鹰队', '1002', '1', '2', '3', '4', '5');
INSERT INTO `team` VALUES ('3', '山猫队', '1003', '1', '2', '3', '4', '5');
INSERT INTO `team` VALUES ('4', '火凤凰队', '1004', '1', '2', '3', '4', '5');
INSERT INTO `team` VALUES ('5', '安信工队', '1005', '1', '2', '3', '4', '5');
INSERT INTO `team` VALUES ('6', '闪电队', '1006', '1', '2', '3', '4', '5');

-- ----------------------------
-- Table structure for upload
-- ----------------------------
DROP TABLE IF EXISTS `upload`;
CREATE TABLE `upload` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) DEFAULT NULL,
  `fpath` varchar(255) DEFAULT NULL,
  `fsize` float(11,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of upload
-- ----------------------------
INSERT INTO `upload` VALUES ('1', '第三次作业第六组张兴.docx', '.docx', '0');
INSERT INTO `upload` VALUES ('2', '11.docx', 'web/11.docx', '0');
INSERT INTO `upload` VALUES ('3', '11.docx', 'web/11.docx', '0');
INSERT INTO `upload` VALUES ('4', '11.docx', 'web/11.docx', '0');
INSERT INTO `upload` VALUES ('5', '11.docx', 'web/11.docx', '0');
INSERT INTO `upload` VALUES ('6', '11.docx', 'web/11.docx', '0');
INSERT INTO `upload` VALUES ('7', '第六组晨会++.xlsx', 'web/第六组晨会++.xlsx', '0');
