



<html>
<style>
body{
	padding:0;
	margin:0;
	
}
#wrap{
	width:100%;
	height:100%;
}



 						/* 已访问的链接 */
	#title:hover {
		
	 font-size:150%;
		       background:#87CEFA;
	}							/* 鼠标移动到链接上 */


	#title {
			background: #B1D2EC;
			width: 100%;
			height: 60px;
			}
			#title img {
			margin-left: 550px;
			}
			#title-left {
			float: left;
			}
			#title-right {
			float: right;
			font-size: 24px;
			font-weight:bold;
			font-family:"华文行楷";
			margin-right: 500px;
			margin-top:20px;
			}
			
			#left{
				font-size:16px;
				font-family:"宋体";
			margin-top:0px;
		    margin-left:0px;
			float:left;
            width:10%;
			height:800px;	
				background:	#B0E0E6;		
			}
			#right{
			height:800px;
					
			margin-top:0px;
            width:90%;
			float:right;
				background:#E0EEE0;
			}

			ul li{
				line-height:35px;
            	list-style:none;
			}
			ul li a{
				line-height:50px;
            	list-style:none;
				
	      text-decoration:none;
			}
          a:link{
	         color:black;
			}
			a:visited{
	        color:blue;
			}
			a:hover{
			font-size:150%;
	        color:red;
			}
			input{
	         width:150px;
				height:30px
			}

</style>
<head>
</head>
<body>
<div id="wrap">
			<div id="title">
				<div id=title-left>

					<a href="http://www.ahpumec.edu.cn/"><img src="img/school.png" /></a>
				</div>
				<div id=title-right>
					<marquee>安徽信息工程学院学科竞赛管理系统</marquee>

				</div>
			</div>

				<div id="left">
				<h3>导航菜单</h3>
				
				<ul>
				        <li><a href="HomePage.php"target="parent" style="border-right:1px solid color;">网站首页</a></li>			       
						<li><a href="NewsCenter.php">新闻中心</a></li>
						<li><a href="Announce.php">通知公告</a></li>
						<li><a href="Mannger.php">管理规定</a></li>
						<li><a href="ContestsProject.php">竞赛项目</a></li>
						<li><a href="CompetitionResult.php">竞赛成果</a></li>
						<li><a href="newfile.php">文件下载</a></li>
						<li><a href="ContactUs.php">联系我们</a></li>
						<li><a href="FriendLink.php">友情链接</a></li>
						<li><a href="UsingHelp.php">使用帮助</a></li>
					     <li><a href="Login.php">用户登陆</a></li>	
					   	
				</ul>	
				</div>
				<div id="right">
				<h3>学科竞赛文件上传</h3>
				<hr/>
					
 <form action="xiazaiAction.php" method="post" enctype="multipart/form-data" >
  <input type="file" name="upfile[]" style="font-size:22px;margin-left:30px;"/>
  <input type="submit" value="文件上传" style="margin-left:40px;">
 
   </form>

				</div>
			</div>

</body>
</html>