<?php 
include 'newfile.php';


$sql="select*from upload";
$result=mysql_query($sql);
echo "<table>";
echo"<tr><th>文件名</th></tr>";
while ($row=mysql_fetch_array($result)){
    echo"<tr><td><a href='$row[fpath]'>'$row[fname]'</a></td></tr>";
}
echo "</table>";

$upName = array_filter($_FILES['upfile']['name']);
foreach($upName as $k=>$v){
    if(is_uploaded_file($_FILES['upfile']['tmp_name'][$k])){
        //$newPath='web/'.$v;
       //   $v=iconv("UTF-8","gb2312", $v);
      //  $v=iconv("UTF-8","gbk", $v);
        $newPath='web/'.$v;
        move_uploaded_file($_FILES['upfile']['tmp_name'][$k], $newPath);
      // $v=iconv("utf8","gbk", $v);
       // $v=iconv("gb2312","UTF-8", $v);
     //  $v=iconv("gbk","UTF-8", $v);
        $sql="insert into upload (fname,fpath,fsize) values ('$v','$newPath','.filesize($newPath).')";
       
        $result=mysql_query($sql);
    }
}
echo "<script>alert('上传成功');history.go(-1);</script>";
?>